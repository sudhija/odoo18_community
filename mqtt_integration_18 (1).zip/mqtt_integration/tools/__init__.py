# -*- coding: utf-8 -*-
from . import odoo_restart_handler
