# In my_module/models/globals.py
# domain_partin = []
# domain_partout =[]
func_mod = 'vitouzkf.func'
msg_sep = ', '


# def set_domain_partin(value):
#     global domain_partin
#     domain_partin = value
# def get_domain_partin():
#     return domain_partin
