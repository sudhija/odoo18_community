from . import extension
from . import intent
from . import sale_order
from . import payment_transaction
from . import account_move
from . import hotel_room    
from . import room_booking
from . import sale_order_line