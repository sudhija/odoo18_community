import logging
from odoo import http
from odoo.http import request

logger = logging.getLogger(__name__)

class ZkController(http.Controller):

    # Accept both POST and GET (some devices send GET) and also accept a trailing slash.
    @http.route(['/iclock/cdata', '/iclock/cdata/'], type='http', auth='none', methods=['GET', 'POST'], csrf=False)
    def receivedata(self, **kwargs):
        # SN and other params may be sent as query params; data payload in request body.
        sn = kwargs.get('SN') or request.httprequest.args.get('SN')
        try:
            data = request.httprequest.data.decode('utf-8') if request.httprequest.data else ''
        except Exception:
            data = ''

        logger.info(f"Received data from device {sn}: payload_len={len(data)} args={dict(request.httprequest.args)}")

        if not data:
            # Some devices send data as query param 'data' or via GET; try to extract.
            data = kwargs.get('data') or request.httprequest.args.get('data') or ''

        for line in data.splitlines():
            if not line.strip():
                continue
            parts = line.strip().split()
            try:
                userid, datepart, timepart = parts[:3]
            except Exception:
                logger.debug(f"Skipping malformed line from device {sn}: '{line}'")
                continue
            timestamp = datepart + " " + timepart

            employee = request.env['hr.employee'].sudo().search([('barcode', '=', userid)], limit=1)
            if employee:
                try:
                    request.env['hr.attendance'].sudo().create({
                        'employee_id': employee.id,
                        'check_in': timestamp,
                    })
                    logger.info(f"Attendance created for {employee.name} at {timestamp}")
                except Exception:
                    logger.exception(f"Failed to create attendance for {userid} at {timestamp}")
            else:
                logger.warning(f"No employee found for ID {userid}")

        # ZKTeco devices expect plain text OK or similar. Return 200 with OK body.
        return request.make_response('OK', [('Content-Type', 'text/plain')])

    @http.route('/iclock/getrequest', type='http', auth='none', methods=['GET'], csrf=False)
    def getrequest(self, **kwargs):
        sn = kwargs.get('SN')
        logger.info(f"Device {sn} requested command check")
        return "OK"

    # Debugging catch-all: logs any request under /iclock/* so we can see what the device actually sends
    @http.route(['/iclock', '/iclock/<path:sub>'], type='http', auth='none', methods=['GET', 'POST'], csrf=False)
    def iclock_catchall(self, sub=None, **kwargs):
        req = request.httprequest
        args = dict(req.args) if req.args else {}
        logger.info(f"ICLOCK CATCHALL: sub={sub} method={req.method} remote={req.remote_addr} args={args} content_len={len(req.data or b'')}")
        # Return 200 with a simple body so devices know the endpoint is reachable
        return request.make_response('OK', [('Content-Type', 'text/plain')])
