from odoo import models, fields

class HotelFacility(models.Model):
    _name = 'hotel.facility'
    _description = 'Hotel Facility'

    name = fields.Char(string='Name', required=True)
    icon_image = fields.Image("Icon Image", max_width=64, max_height=64)

class HotelRoomInherit(models.Model):
    _inherit = 'hotel.room'

    facility_ids = fields.Many2many('hotel.facility', string='Facilities')
